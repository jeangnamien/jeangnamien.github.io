from embedding_simulator import Embedding_simulator
from JPEG_utils import *
from antecedent.image import Image
from antecedent.pipeline import ComposedPipeline,create_pipeline
import numpy as np
import jpeglib as jl
from PIL import Image as PILImage
import os

WET_COST = 1e13
WET_COST_ROB = 1e10

def get_libjpeg_qt(qf, im_name='tmp.jpg'):
       """
       This function retrieves the libjpeg-qt library's JPEG quantization table for a given quality factor.

       Parameters:
       qf (int): The quality factor for the JPEG image.
       im_name (str): The name of the temporary image file. Default value is 'tmp.jpg'.

       Returns:
       The JPEG quantization table for the given quality factor.
       """
       im_name = '/tmp/' + str(im_name)
       I = PILImage.fromarray(np.ones((8,8), dtype=np.uint8))
       I.save(im_name, quality=qf)
       S = jl.to_jpegio(jl.read_dct(im_name))
       os.remove(im_name)
       return S.quant_tables[0]

# UERD functions

def compute_cost(energies, c_quant):
    """
    Computation of costs
    """
    (m, n) = energies.shape
    m -= 2
    n -= 2
    k = m * 8
    l = n * 8
    rho = np.zeros((k, l))
    for block_row in range(m):
        for block_col in range(n):
            block_rho = energies[block_row + 1][block_col + 1] + \
                                (energies[block_row][block_col] + \
                                    energies[block_row][block_col + 1] + \
                                    energies[block_row][block_col + 2] + \
                                    energies[block_row + 1][block_col] + \
                                    energies[block_row + 1][block_col + 2] + \
                                    energies[block_row + 2][block_col + 1] + \
                                    energies[block_row + 2][block_col] + \
                                    energies[block_row + 2][block_col + 2]) * 0.25
            if (block_rho == 0):
                rho[block_row * 8:(block_row + 1) * 8, block_col * 8:(block_col + 1) * 8] = WET_COST
            else:
                for row in range(8):
                    for col in range(8):
                        if (row == 0 and col == 0):
                            mode_rho = 0.5 * (c_quant[0][1] + c_quant[1][0])
                        else:
                            mode_rho = c_quant[row][col]
                        rho[block_row * 8 + row][block_col * 8 + col] = (mode_rho / block_rho)

    return rho

def compute_Dmn(c_coeffs, c_quant):
    """
    Comutation of energies of blocks
    """
    (m, n) = c_coeffs.shape
    m = m // 8
    n = n // 8
    energies = np.zeros((m+2, n+2))
    for block_row in range(m):
        for block_col in range(n):
            current_block = np.copy(c_coeffs[block_row * 8:(block_row + 1) * 8,block_col * 8:(block_col + 1) * 8])
            current_block[0][0] = 0
            for row in range(8):
                for col in range(8):
                    energies[block_row + 1][block_col + 1] += abs(current_block[row][col]) * c_quant[row][col]

    energies[0][0] = energies[1][1]
    energies[0][n+1] = energies[1][n]
    energies[m+1][0] = energies[m][1]
    energies[m+1][n+1] = energies[m][n]
    for block_row in range(m):
        energies[block_row + 1][0] = energies[block_row + 1][1]
        energies[block_row + 1][n+1] = energies[block_row + 1][n]
    for block_col in range(n):
        energies[0][block_col + 1] = energies[1][block_col + 1]
        energies[m+1][block_col + 1] = energies[m][block_col + 1]

    return energies

def UERD(c_coeffs, c_quant):
    """
    Compute costs according to cover in spatial and DCT domains
    """
    # Compute the block energies
    energies = compute_Dmn(c_coeffs, c_quant)
    # Compute rhos
    rho = compute_cost(energies, c_quant)
    # Adjust embedding costs
    rho[rho > WET_COST] = WET_COST # Threshold on the costs
    rho[np.isnan(rho)] = WET_COST # Check if all elements are numbers
    return rho


def compute_rhos(c_coeffs, c_quant):
    rho = UERD(c_coeffs, c_quant)

    rhoP1 = np.copy(rho)
    rhoM1 = np.copy(rho)

    rhoP1[c_coeffs > 1023] = WET_COST # Do not embed +1 if the DCT coeff has max value
    rhoM1[c_coeffs < -1023] = WET_COST # Do not embed -1 if the DCT coeff has min value

    return rhoP1, rhoM1

# Embedding functions


def Embed_robust(im_name, img, is_jpeg, alpha, rho_func, QF, QF_init=None, search_steps=10):
       """
       This function performs robust embedding of a given image using a libjpeg compressor.

       Parameters:
       im_name (str): The name of the image file to be used as the precover image.
       img (numpy.ndarray): The precover image to be compressed to a cover image.
       is_jpeg (bool): A flag indicating whether the precover image is in JPEG format (True) or uncompressed (False).
       alpha (float): The embedding payload in terms of bits per non-zero AC DCT coefficients
       rho_func (function): The function to compute the costs for embedding. Returns tuple of costs associated to +1 and -1 changes.
       QF (int): The quality factor for the JPEG image.
       QF_init (int, optional): Thequality factor of the first JPEG compression in case of double compression pipeline. Default value is None (only single compression).
       search_steps (int, optional): The number of search steps for finding the antecedent. Default value is 10.

       Returns:
       tuple: A tuple containing the stego antecedent, the stego image, the cover image, the quantization table, and the pipeline used.
       """
       if is_jpeg: # Recompression on a JPEG
              pipeline_to_px = create_pipeline('islow', QF_init, True, target_is_dct=False)  # Islow pipeline with QF
              pipeline_to_dct = create_pipeline('islow', QF, True, target_is_dct=True)  # Islow pipeline with QF
              pipeline = ComposedPipeline([pipeline_to_px,pipeline_to_dct])
              pipeline_last = pipeline_to_dct
       else:
              if QF_init is None: # Single compression on an uncompressed image
                     pipeline = create_pipeline('islow', QF, True, target_is_dct=True)
                     pipeline_last = pipeline
              else: # Double compression on an uncompressed image
                     pipeline_to_dct = create_pipeline('islow', QF_init, True, target_is_dct=True)  # Islow pipeline with QF
                     pipeline_to_px = create_pipeline('islow', QF_init, True, target_is_dct=False)  # Islow pipeline with QF
                     pipeline_to_dct2 = create_pipeline('islow', QF, True, target_is_dct=True)  # Islow pipeline with QF
                     pipeline = ComposedPipeline([pipeline_to_dct, pipeline_to_px,pipeline_to_dct2])
                     pipeline_last = pipeline_to_dct2
       precover = Image('precover', img, is_jpeg=is_jpeg)

       Q = get_libjpeg_qt(QF, im_name + '.jpg')
       img2 = pipeline.forward(precover.data)
       cover = reshape_view_to_original(img2, img) # cover image to be embedded
       cover_view = view_as_blocks(cover, (8,8))
       nzAC = np.count_nonzero(cover_view) - np.count_nonzero(cover_view[:,:,0,0])
       m = round(nzAC*float(alpha))
       rhoP1, rhoM1 = rho_func(cover, Q)

       keep_search = True
       antecedent = np.zeros_like(cover_view)

       while keep_search:
              count_notfound = 0
              keep_search = False

              # desired compressed stego image
              pP1, pM1 = Embedding_simulator.compute_proba(rhoP1, rhoM1, m, cover.size)
              S = Embedding_simulator.process(np.copy(cover), pP1, pM1)
              stego_view = view_as_blocks(S,  (8,8))

              # antecedent search
              img2 = Image('toy_example', S, is_jpeg=True)
              img2.set_pipeline(pipeline_last)
              img2.set_selection_parameter('changes', 100, changes=np.any(cover_view!=stego_view, axis=(-1,-2)))
              img2.search_antecedent(search_steps)

              rhoP1_view = view_as_blocks(rhoP1, (8,8))
              rhoM1_view = view_as_blocks(rhoM1, (8,8))
              changes = stego_view-cover_view

              for i in range(stego_view.shape[0]):
                     for j in range(stego_view.shape[1]):
                            if not np.any(changes[i,j]):
                                   antecedent[i,j] = precover.data[i,j]
                            elif img2.block_collection[i,j].status[pipeline_last] ==0:
                                   # Nonrobust branch
                                   idx = changes[i,j]>0
                                   rhoP1_view[i,j][idx] = WET_COST_ROB
                                   idx = changes[i,j]<0
                                   rhoM1_view[i,j][idx] = WET_COST_ROB
                                   count_notfound+=1
                                   keep_search = True
                            else:
                                   antecedent[i,j] = np.squeeze(img2.block_collection[i,j].antecedents[pipeline_last][0])
              print('not found: ' + str(count_notfound))
       return reshape_view_to_original(antecedent, cover), S, cover, Q, pipeline


def Embed(im_name, quality, payload, rho_func=compute_cost):
    """
    Given JPEG steganographic costs, embeds a given image with robust embedding changes against a libjpeg compressor.

    Parameters:
    im_name (str): The name of the image file to be used as the precover image.
    quality (int): The quality factor for the JPEG image.
    payload (float): The desired payload in bits per non-zero AC DCT coefficients
    rho_func (function, optional): The function to compute the costs for embedding. Returns tuple of costs associated to +1 and -1 changes

    Returns:
    tuple: A tuple containing the stego antecedent, the stego image, and the cover image.
    """
    is_jpeg = 'jpg' in im_name or 'jpeg' in im_name # False only if providing uncompressed image
    image = np.array(PILImage.open(im_name))


    antecedent, stego, cover, Q, pipeline = Embed_robust(im_name, image, is_jpeg, payload, rho_func, quality)

    ant = Image('antecedent', antecedent, is_jpeg=is_jpeg)
    compressed_antecedent = reshape_view_to_original(pipeline.forward(ant.data), antecedent)

    if np.sum(compressed_antecedent != stego) > 0:
        print('Warning: Some coefficients have changed during the compression!')

    return antecedent, stego, cover # return the stego antecedent, stego image, and cover image
