import os

import jpeglib
from PIL import Image as Img
from skimage.util import view_as_blocks
import numpy as np

from .block import Block
from .pipeline import NaivePipeline, create_pipeline


class Image:
    """
    A class to read images (JPEG or pixels) and stored them into a collection of blocks.

    This class can be useful for:
     - converting RGB image into YCbCr or grayscale (not implemented)
     - detecting the grid of a decompressed image (not implemented)
     - detecting the quantization table of a decompressed image (not implemented)
     - selecting most interesting blocks among the image (not implemented)
    """

    def __init__(self, filename, path):
        self.filename = filename
        self.pipeline = None
        self.avoid_uniform = True
        self.avoid_clipped = True
        self.selection_percentage = 100
        self.method_name = 'random'
        self.pmap = None
        self.rng = None
        self.img = None
        self.block_collection = {}
        self.is_jpeg = False
        self.selected_blocks = []
        self.is_filtered = False

        ext = os.path.splitext(path)[-1].lower()

        if ext in ['.jpg', '.jpeg']:
            self.is_jpeg = True
            self.img = jpeglib.read_dct(path)
            self.is_grayscale = not self.img.has_chrominance
            if self.is_grayscale:
                self.data = np.stack([self.img.Y], axis=2)  # shape (None, None, 3, 8, 8)
            else:
                self.data = np.stack([self.img.Y, self.img.Cb, self.img.Cr], axis=2)  # shape (None, None, 3, 8, 8)
            for i in range(self.data.shape[0]):
                for j in range(self.data.shape[1]):
                    self.block_collection[(i, j)] = Block(self.data[i, j], pos=(i, j))
        else:
            self.img = Img.open(path)
            self.data = np.asarray(self.img)
            self.is_grayscale = self.img.mode == 'L'
            cropped_img = self.data[:8 * (self.data.shape[0] // 8), :8 * (self.data.shape[1] // 8)]
            if self.data.ndim == 2:
                block_shape = (8, 8)
            else:
                block_shape = (8, 8, 1)
            block_view = view_as_blocks(cropped_img, block_shape)
            for i in range(block_view.shape[0]):
                for j in range(block_view.shape[1]):
                    self.block_collection[(i, j)] = Block(block_view[i, j].reshape(-1, 8, 8), pos=(i, j))

    def __init__(self, filename, img, is_jpeg):
        self.filename = filename
        self.pipeline = None
        self.avoid_uniform = False
        self.avoid_clipped = False
        self.selection_percentage = 100
        self.method_name = 'random'
        self.pmap = None
        self.rng = None
        self.img = img
        self.block_collection = {}
        self.is_jpeg = is_jpeg
        self.selected_blocks = []
        self.is_filtered = False
        self.is_grayscale = img.ndim == 2


        cropped_img = self.img[:8 * (self.img.shape[0] // 8), :8 * (self.img.shape[1] // 8)]
        if self.is_grayscale:
            block_shape = (8, 8)
        else:
            block_shape = (8, 8, 1)
        block_view = view_as_blocks(cropped_img, block_shape)
        self.data = view_as_blocks(cropped_img, block_shape)
        for i in range(block_view.shape[0]):
            for j in range(block_view.shape[1]):
                self.block_collection[(i, j)] = Block(block_view[i, j].reshape(-1, 8, 8), pos=(i, j))


    def set_pipeline(self, pipeline):
        self.pipeline = pipeline

    def set_filter_parameter(self, avoid_clipped, avoid_uniform):
        self.avoid_clipped = avoid_clipped
        self.avoid_uniform = avoid_uniform

    def set_selection_parameter(self, method_name, percentage, pmap=None, changes=None, rng=None):
        self.method_name = method_name
        self.selection_percentage = percentage
        self.pmap = pmap
        self.rng = rng
        self.changes = changes
        if self.rng is None:
            self.rng = np.random.RandomState()

    def search_antecedent(self, max_iter, shared_dict=None, task_id=None, verbose=False, split_search_if_possible=True):
        self.filter_block()
        blocks = self.select_blocks()
        if self.is_jpeg and self.pipeline.n == 1 and split_search_if_possible:
            # Single pipeline from Pixel to DCT, we can search a pixel antecedent for each channel independently
            # A similar pipeline is created but without color conversion
            names = [pipe.name for pipe in self.pipeline.pipelines]
            qualities = [pipe.quality for pipe in self.pipeline.pipelines]
            self.grayscale_pipeline = create_pipeline(names, qualities, grayscale=self.is_grayscale, target_is_dct=True)

        for i, block in enumerate(blocks):
            if shared_dict is not None and task_id is not None:
                shared_dict[task_id] = {"filename": self.filename,
                                        "current_block": i + 1,
                                        "total_block": len(blocks),
                                        "completed": 0,
                                        "total": 0}

            if self.is_jpeg and self.pipeline.n == 1 and split_search_if_possible:
                # Case where the channel are independent
                antecedents = []
                iterations = []
                status = 1
                for channel in block.value:
                    single_channel_block = Block(np.array([channel]), pos=block.pos)
                    antecedent, iteration = single_channel_block.search_antecedent(self.grayscale_pipeline,
                                                                                   max_iter,
                                                                                   shared_dict,
                                                                                   task_id,
                                                                                   verbose)
                    if antecedent is None:
                        antecedent = -np.ones((1, 8, 8))
                        status = 0
                    antecedents.append(antecedent)
                    iterations.append(iteration)

                block.antecedents[self.pipeline] = (np.stack(antecedents, axis=0), np.sum(iterations))
                block.status[self.pipeline] = status
            else:
                block.search_antecedent(self.pipeline, max_iter, shared_dict, task_id, verbose)

    def search_antecedent_ilp(self, parameters, shared_dict, task_id, verbose):
        if (not self.is_jpeg
                or not isinstance(self.pipeline, NaivePipeline)
                or not np.allclose(self.pipeline.quant_tbl, np.ones((8, 8)))):
            raise ValueError('Gurobi search is only effective for JPEG images at QF100 with the naive pipeline.')

        self.filter_block()
        blocks = self.select_blocks()

        gurobi_parameters = {'IterationLimit': parameters['max_iteration_per_block'],
                             'MIPFocus': parameters['mip_focus'],
                             'Threads': parameters['threads'],
                             'NodefileStart': parameters['node_file_start'],
                             'Cutoff': parameters['cutoff']}
        for i, block in enumerate(blocks):
            shared_dict[task_id] = {"filename": self.filename,
                                    "current_block": i + 1,
                                    "total_block": len(blocks),
                                    "completed": 0,
                                    "total": 0}
            block.search_antecedent_ilp(gurobi_parameters, shared_dict, task_id, verbose)

    def classify(self, likelihood_file):
        # TODO: add the LRT test

        pass

    def filter_block(self):
        if self.is_filtered:
            return
        if not (self.avoid_clipped or self.avoid_uniform):
            return
        elif not self.is_jpeg:
            for _, block in self.block_collection.items():
                spatial_block = np.array([block.value])
                clipped = np.any(spatial_block >= 255) | np.any(spatial_block <= 0)
                uniform = np.unique(spatial_block).size == 1
                if self.avoid_clipped & clipped or self.avoid_uniform & uniform:
                    block.ignore(self.pipeline)
            self.is_filtered = True
        else:
            for _, block in self.block_collection.items():
                spatial_block = self.pipeline.backward(np.array([block.value]))
                clipped = np.any(spatial_block >= 255) | np.any(spatial_block <= 0)
                uniform = np.unique(spatial_block).size == 1
                if self.avoid_clipped & clipped or self.avoid_uniform & uniform:
                    block.ignore(self.pipeline)
            self.is_filtered = True

    def select_blocks(self, purge=False):
        if np.any(self.selected_blocks) and not purge:
            return self.selected_blocks
        n = min(int(len(self.block_collection) * self.selection_percentage / 100), len(self.block_collection))
        if self.method_name == 'random':
            potential_blocks = [b for _, b in self.block_collection.items() if not b.ignored]
            self.selected_blocks = self.rng.choice(potential_blocks,
                                                   size=min(len(potential_blocks), n),
                                                   replace=False)
            return self.selected_blocks
        elif self.method_name == 'changes':
            self.selected_blocks = np.array([b for k,b in self.block_collection.items() if self.changes[k]])
            return self.selected_blocks
        else:
            raise NotImplementedError

    def detect_grid(self):
        pass

    def detect_quant_tbl(self):
        pass

    def handle_color(self):
        pass
